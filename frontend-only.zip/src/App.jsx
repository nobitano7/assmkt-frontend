import { useState } from "react";

function App() {
  const [platform, setPlatform] = useState("Facebook");
  const [goal, setGoal] = useState("Bán hàng");
  const [trend, setTrend] = useState("");
  const [inputContent, setInputContent] = useState("");
  const [customPrompt, setCustomPrompt] = useState("");
  const [output, setOutput] = useState("");

  const generateContent = async () => {
    const res = await fetch(
      "https://assmkt-backend.onrender.com/api/generate",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platform, goal, trend, inputContent, customPrompt })
      }
    );
    const data = await res.json();
    setOutput(data.output);
  };

  return (
    <div className="p-6 max-w-3xl mx-auto text-white bg-gray-900 min-h-screen">
      <h1 className="text-3xl font-bold mb-4">🚀 Trợ lý Marketing Viral</h1>

      <label>1. Nền tảng:</label>
      <select value={platform} onChange={e => setPlatform(e.target.value)} className="w-full p-2 mb-3 text-black">
        <option>Facebook</option>
        <option>Instagram</option>
        <option>TikTok</option>
        <option>Zalo</option>
        <option>Blog</option>
      </select>

      <label>2. Mục tiêu:</label>
      <select value={goal} onChange={e => setGoal(e.target.value)} className="w-full p-2 mb-3 text-black">
        <option>Bán hàng</option>
        <option>Chia sẻ giá trị</option>
        <option>Kể chuyện</option>
        <option>Chứng thực xã hội</option>
        <option>Tương tác & Cập nhật</option>
      </select>

      <label>3. Xu hướng (optional):</label>
      <input value={trend} onChange={e => setTrend(e.target.value)} className="w-full p-2 mb-3 text-black" placeholder="Ví dụ: Marketing AI" />

      <label>4. Nội dung gốc:</label>
      <textarea value={inputContent} onChange={e => setInputContent(e.target.value)} className="w-full p-2 mb-3 text-black" rows="4" />

      <label>5. Prompt tùy chỉnh:</label>
      <textarea value={customPrompt} onChange={e => setCustomPrompt(e.target.value)} className="w-full p-2 mb-3 text-black" rows="3" />

      <button onClick={generateContent} className="bg-purple-600 px-4 py-2 rounded">✨ Tạo nội dung Viral</button>

      <h2 className="text-xl mt-5">6. Kết quả:</h2>
      <div className="bg-gray-800 p-3 rounded mt-2 min-h-[100px]">
        {output || "Chưa có kết quả"}
      </div>
    </div>
  );
}

export default App;